package server.server;

public class Server {
}
