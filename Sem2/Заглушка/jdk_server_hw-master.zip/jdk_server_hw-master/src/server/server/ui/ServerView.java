package server.server.ui;

public interface ServerView {
    void showMessage(String message);
}
