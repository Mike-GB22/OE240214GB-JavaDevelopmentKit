package server.client.ui;

public interface ClientView {
    void showMessage(String message);
    void disconnectFromServer();
}
